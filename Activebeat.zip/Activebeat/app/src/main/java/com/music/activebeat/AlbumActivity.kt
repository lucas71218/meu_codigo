package com.music.activebeat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.album_layout.*


class AlbumActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.album_layout)

        // Dados fictícios de álbuns (substitua com seus próprios dados)
        val albums = listOf(
            Album("Album 1", "Artista 1"),
            Album("Album 2", "Artista 2"),
            Album("Album 3", "Artista 3")
        )

        // Configurar o RecyclerView
        val layoutManager = LinearLayoutManager(this)
        albumRecyclerView.layoutManager = layoutManager
        val adapter = AlbumAdapter(albums)
        albumRecyclerView.adapter = adapter
    }
}