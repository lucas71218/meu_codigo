package com.music.activebeat

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.music.activebeat.ui.theme.ActivebeatTheme

class MusicActivity : AppCompatActivity() {

    private lateinit var musicAdapter: MusicAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)

        val titleTextView: TextView = findViewById(R.id.title_textview)
        titleTextView.text = "Músicas"

        val musicRecyclerView: RecyclerView = findViewById(R.id.music_recycler_view)
        musicAdapter = MusicAdapter()

        // Configurar RecyclerView
        musicRecyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = musicAdapter
            addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
        }

        // Carregar e exibir as músicas (simulado)
        val musicList = loadMusicData()
        musicAdapter.submitList(musicList)
    }

    private fun loadMusicData(): List<Music> {
        // Implemente a lógica para carregar as músicas (por exemplo, de um banco de dados ou recurso)
        // Este é apenas um exemplo simulado
        return listOf(
            Music("Nome da Música 1", "Artista 1"),
            Music("Nome da Música 2", "Artista 2"),
            Music("Nome da Música 3", "Artista 3"),
            // Adicione mais músicas conforme necessário
        )
    }
}