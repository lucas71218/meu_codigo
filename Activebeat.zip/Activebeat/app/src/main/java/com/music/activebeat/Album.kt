package com.music.activebeat

data class Album(val title: String, val artist: String)
