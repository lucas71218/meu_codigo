package com.music.activebeat

data class Music(
    val title: String,
    val artist: String
)

