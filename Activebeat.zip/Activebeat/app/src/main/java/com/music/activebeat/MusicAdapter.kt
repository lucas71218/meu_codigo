package com.music.activebeat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MusicAdapter : RecyclerView.Adapter<MusicAdapter.MusicViewHolder>() {

    private var musicList: List<Music> = listOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_music, parent, false)
        return MusicViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MusicViewHolder, position: Int) {
        val currentMusic = musicList[position]
        holder.titleTextView.text = currentMusic.title
        holder.artistTextView.text = currentMusic.artist
    }

    override fun getItemCount(): Int {
        return musicList.size
    }

    fun submitList(musicList: List<Music>) {
        this.musicList = musicList
        notifyDataSetChanged()
    }

    class MusicViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.title_textview)
        val artistTextView: TextView = itemView.findViewById(R.id.artist_textview)
    }
}
