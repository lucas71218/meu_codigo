package com.music.activebeat

import android.content.Context
import android.media.MediaPlayer

class MusicPlayer(context: Context) {
    private var mediaPlayer: MediaPlayer? = null

    fun playMusic(context: Context, musicResId: Int) {
        stopMusic()
        mediaPlayer = MediaPlayer.create(context, musicResId)
        mediaPlayer?.start()
    }

    fun pauseMusic() {
        mediaPlayer?.pause()
    }

    fun stopMusic() {
        mediaPlayer?.apply {
            if (isPlaying) {
                stop()
            }
            release()
        }
        mediaPlayer = null
    }
}
