package com.music.activebeat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.music.activebeat.ui.theme.ActivebeatTheme

class MainActivity : AppCompatActivity() {
    private lateinit var musicPlayer: MusicPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        musicPlayer = MusicPlayer(this)

        val playButton: Button = findViewById(R.id.play_button)
        val pauseButton: Button = findViewById(R.id.pause_button)
        val stopButton: Button = findViewById(R.id.stop_button)
        val musicTitleTextView: TextView = findViewById(R.id.music_title_text_view)

        val musicResId = R.raw.sample_music // Substitua com o recurso de áudio desejado

        playButton.setOnClickListener {
            musicPlayer.playMusic(this, musicResId)
            musicTitleTextView.text = "Sample Music" // Substitua com o nome da música
        }

        pauseButton.setOnClickListener {
            musicPlayer.pauseMusic()
        }

        stopButton.setOnClickListener {
            musicPlayer.stopMusic()
            musicTitleTextView.text = ""
        }
    }
}